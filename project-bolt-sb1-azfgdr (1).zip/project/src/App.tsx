import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Briefcase, GraduationCap, Award, Languages, Code2, Heart } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 relative">
      {/* Decorative background elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(147,197,253,0.15),transparent_40%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(167,139,250,0.1),transparent_40%)]" />
      
      <header className="relative bg-white/80 backdrop-blur-sm shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl font-bold text-gray-900 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Mahmoud Ramadan Mousa
            </h1>
            <div className="mt-4 flex flex-wrap gap-4 text-gray-600">
              <div className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                <span>Cairo, Egypt</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5" />
                <a href="mailto:mahmoudmou21@gmail.com" className="hover:text-blue-600 transition-colors">
                  mahmoudmou21@gmail.com
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5" />
                <span>01287051290</span>
              </div>
            </div>
          </motion.div>
        </div>
      </header>

      <main className="relative max-w-5xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="space-y-12">
          {/* Objective */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
          >
            <h2 className="text-2xl font-semibold text-gray-900 mb-4">Objective</h2>
            <p className="text-gray-600">
              As a fresh pharmacy graduate, I seek to gain valuable experience in the field while applying and further
              developing the skills I have acquires through various internships and work experiences.
            </p>
          </motion.section>

          {/* Education */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
          >
            <div className="flex items-center gap-2 mb-4">
              <GraduationCap className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-semibold text-gray-900">Education</h2>
            </div>
            <div className="border-l-2 border-blue-200 pl-4">
              <h3 className="text-lg font-semibold text-gray-900">Heliopolis University</h3>
              <p className="text-gray-600">Bachelor of Pharmacy</p>
              <p className="text-gray-500">2018 - 2023</p>
            </div>
          </motion.section>

          {/* Work Experience */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
          >
            <div className="flex items-center gap-2 mb-4">
              <Briefcase className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-semibold text-gray-900">Work Experience</h2>
            </div>
            <div className="space-y-6">
              <div className="border-l-2 border-blue-200 pl-4">
                <h3 className="text-lg font-semibold text-gray-900">Suez Military Hospital</h3>
                <p className="text-gray-600">Inpatient Pharmacist</p>
                <p className="text-gray-500">December 2023</p>
              </div>
              <div className="border-l-2 border-blue-200 pl-4">
                <h3 className="text-lg font-semibold text-gray-900">Ahmed Ali Pharmacy</h3>
                <p className="text-gray-600">Community Pharmacist</p>
                <p className="text-gray-500">May 2022</p>
              </div>
            </div>
          </motion.section>

          {/* Training Courses */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
          >
            <div className="flex items-center gap-2 mb-4">
              <Award className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-semibold text-gray-900">Training Courses</h2>
            </div>
            <div className="space-y-4">
              <div className="border-l-2 border-blue-200 pl-4">
                <h3 className="text-lg font-semibold text-gray-900">El Wahat Visit with public health team</h3>
                <p className="text-gray-600">Managed by Heliopolis University</p>
                <p className="text-gray-500">March 2023</p>
              </div>
              <div className="border-l-2 border-blue-200 pl-4">
                <h3 className="text-lg font-semibold text-gray-900">El Zagazig Educational Hospital</h3>
                <p className="text-gray-600">40 hours training</p>
                <p className="text-gray-500">August 2022</p>
              </div>
              <div className="border-l-2 border-blue-200 pl-4">
                <h3 className="text-lg font-semibold text-gray-900">13 Villages Community Development Project</h3>
                <p className="text-gray-600">Managed by SEKEM</p>
                <p className="text-gray-500">May 2022</p>
              </div>
              <div className="border-l-2 border-blue-200 pl-4">
                <h3 className="text-lg font-semibold text-gray-900">Step on the way</h3>
                <p className="text-gray-600">Organized by EPSF</p>
                <p className="text-gray-500">September 2019</p>
              </div>
            </div>
          </motion.section>

          {/* Skills */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
            >
              <div className="flex items-center gap-2 mb-4">
                <Heart className="h-6 w-6 text-blue-600" />
                <h2 className="text-2xl font-semibold text-gray-900">Soft Skills</h2>
              </div>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Presentation Skills</li>
                <li>Negotiation Skills</li>
                <li>Communication Skills</li>
                <li>Time Management</li>
                <li>Team Work</li>
              </ul>
            </motion.section>

            <motion.section
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.7 }}
              className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
            >
              <div className="flex items-center gap-2 mb-4">
                <Code2 className="h-6 w-6 text-blue-600" />
                <h2 className="text-2xl font-semibold text-gray-900">Technical Skills</h2>
              </div>
              <ul className="list-disc list-inside text-gray-600 space-y-2">
                <li>Microsoft Office</li>
                <li>Sales Strategy/Development</li>
                <li>Client Relationship Management</li>
                <li>Patient Counseling</li>
                <li>Market Research and Analysis</li>
              </ul>
            </motion.section>
          </div>

          {/* Languages */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
            className="bg-white/80 backdrop-blur-sm rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 border border-gray-100"
          >
            <div className="flex items-center gap-2 mb-4">
              <Languages className="h-6 w-6 text-blue-600" />
              <h2 className="text-2xl font-semibold text-gray-900">Languages</h2>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Arabic</span>
                <span className="text-gray-500">Native</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">English</span>
                <span className="text-gray-500">Very Good</span>
              </div>
            </div>
          </motion.section>
        </div>
      </main>

      <footer className="relative bg-white/80 backdrop-blur-sm border-t mt-12">
        <div className="max-w-5xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500">© 2024 Mahmoud Ramadan Mousa. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;